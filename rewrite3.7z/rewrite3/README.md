# donsitedev
Donfuer site to catch bugs and show off to people
# log3
rewriting the site a third time lol
redesigning the layout and stuff so that it is better designed. Much to come, this is a tiny incremental update
# log2
tried to fix some bugs, made some things worse, some things better
- Index.html is aggravating, I will make a new layout for it since it was also not too well designed anyways.
- Fixed multiple scrollbar issues on mobile with apply pages - solution isn't much better tho
- Leadership page has TimeofWheel on it, also has a better system that does not throw too much info in your face all at once. Updated DirectorJohnson
- fixed weird bug with mobile nav button
- png icons are deleted in their entirety
- 9b9t apply blurb


TODO:


- scale things for mobile more
- Titlebar centering - can be fixed but mobile scaling needs to happen first
- optimize everything more, everyone complains about the gallery in particular
- fix history, talk to D about updating it to include Donfuer 22 as well as anything notable that happened with the non-anarchy branches
- put a <nojs> element up to warn people about all the terrible things that happen to those foolish enough to care about their privacy
- Layout changes on Index.html
- Change apply page to have details about the branch, leaders, member count, individual history, and extra application details if necessary
  
LONG-TERM TODO:
  
- cookies on the site for anonymous metrics such as average visitor location, average whatever window.navigator info we want, etc
- separate pages for mobile users - gallery.php and any other pages that are really heavy, maybe even use XMLHttpRequest on the desktop site
- a way that D can edit or add stuff to the site without having to know what the fuck I was thinking at 1:30 am cst on January 8th, 2022 when I wrote something the way I did
# For the old changelogs, reference readme.txt

# log1
optimized navpane code for faster page loading, removed some unused code, updated index a tiny bit
- Included remaking the small popup, only inage assets loaded are 3 SVG files, which may even be removed in the future, who knows
- optimized navpane html, divider is a pseudo element now. also did some touch ups on its css
- optimized the title morph a bit, now it is a single html element instead of 3 separate ones - changing css with js
- videos scale with only css, idfk why I did it the other way beforehand
- Requestiong your help --- screenshot any bugs not listed in the TODO and screenshot your user agent (should be in the 9b9t description on apply.html)-----------
